# Instana Agent Install

With the new release of Kubernetes support for Instana, the agent install is now available as a helm [chart](https://github.com/instana/instana-helm-chart). This is the easiest way to install the agent, however if you really want to do it by hand, template descriptors are available in the official [documentation](https://docs.instana.io/ecosystem/kubernetes/).